export interface Drug{
    
    foundGenericName: string;
    foundBrand_name: string;
    foundReaction0: string;
    foundReaction1: string;
    foundReaction2: string;
    relevantCount: number;

}
