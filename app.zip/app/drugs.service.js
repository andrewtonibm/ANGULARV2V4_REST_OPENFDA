"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var Rx_1 = require('rxjs/Rx');
var DrugsService = (function () {
    function DrugsService(http) {
        this.http = http;
        this.URL_allEventListByReaction = 'https://api.fda.gov/drug/event.json?search=patient.reaction.reactionmeddrapt:';
    }
    //*************** getAll() **************************
    DrugsService.prototype.getAllDrugs = function (reactionSelected) {
        console.log('Maker 1');
        var drugs$ = this.http
            .get(this.URL_allEventListByReaction + "%22" + reactionSelected + "%22&limit=100", { headers: this.getHeaders() })
            .map(mapDrugs)
            .catch(handleError);
        console.log('Maker 2');
        return drugs$;
    };
    DrugsService.prototype.getHeaders = function () {
        var headers = new http_1.Headers();
        headers.append('Accept', 'application/json');
        return headers;
    };
    DrugsService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], DrugsService);
    return DrugsService;
}());
exports.DrugsService = DrugsService;
//============================================
function mapDrugs(response) {
    var drugArray = response.json().results.map(toDrug);
    var drugArrayMap = new Map();
    var dropcount = 0;
    for (var i = 0; i < drugArray.length; i++) {
        try {
            var value = drugArray[i];
            var key = value.foundGenericName[0];
            //let existDrug:Drug = drugArrayMap.get(key);
            var existDrug = drugArrayMap.get(key);
            if (typeof existDrug !== "undefined") {
                //DUPLICATED
                dropcount++;
                console.log('Duplicate=' + key);
            }
            else {
                if (value.foundGenericName == "n/a")
                    continue;
                //NEW, not duplicate
                value.relevantCount = 1;
                drugArrayMap.set(key, value);
                console.log('Adding=' + key);
            }
        }
        catch (err) {
            continue;
        }
    }
    ; //for
    var noDuplicatedDrugArray = new Array();
    var mapIter = drugArrayMap.values();
    for (var i = 0; i < drugArrayMap.size; i++) {
        try {
            //let value:Drug = mapIter.next().value;
            var value = mapIter.next().value;
            noDuplicatedDrugArray.push(value);
        }
        catch (err) {
            continue;
        }
    }
    ; //for
    noDuplicatedDrugArray.sort(function (a, b) {
        var nameA = a.relevantCount, nameB = b.relevantCount;
        if (nameA < nameB)
            return 1;
        if (nameA > nameB)
            return -1;
        return 0; //default return value (no sorting)
    });
    return noDuplicatedDrugArray;
}
//*****************************************
function toDrug(r) {
    var tempGenericName = 'n/a';
    try {
        tempGenericName = r.patient.drug[0].openfda.generic_name;
        tempGenericName = tempGenericName.substring(0, 40);
    }
    catch (e) { }
    var tempBrandName = 'n/a';
    try {
        tempBrandName = r.patient.drug[0].openfda.brand_name;
        tempBrandName = tempBrandName.substring(0, 40);
    }
    catch (e) { }
    var tempReaction0 = 'n/a';
    try {
        tempReaction0 = r.patient.reaction[0].reactionmeddrapt;
    }
    catch (e) { }
    var tempReaction1 = 'n/a';
    try {
        tempReaction1 = r.patient.reaction[1].reactionmeddrapt;
    }
    catch (e) { }
    var tempReaction2 = 'n/a';
    try {
        tempReaction2 = r.patient.reaction[2].reactionmeddrapt;
    }
    catch (e) { }
    var drug = ({
        foundGenericName: tempGenericName,
        foundBrand_name: tempBrandName,
        foundReaction0: tempReaction0,
        foundReaction1: tempReaction1,
        foundReaction2: tempReaction2
    });
    //console.log('Parsed drug:', drug);
    return drug;
}
//*****************************************
function mapReaction(response) {
    // toReaction looks just like in the previous example
    return toDrug(response.json());
}
//*****************************************
// this could also be a private method of the component class
function handleError(error) {
    // log error
    // could be something more sofisticated
    var errorMsg = error.message || "Yikes! There was was a problem with our hyperdrive device and we couldn't retrieve your data!";
    console.error(errorMsg);
    // throw an application level error
    return Rx_1.Observable.throw(errorMsg);
}
//# sourceMappingURL=drugs.service.js.map