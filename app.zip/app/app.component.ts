import { Component } from '@angular/core';
import { ReactionsService } from './reactions.service';
import { DrugsService } from './drugs.service';

@Component({
  selector: 'my-app',
  template: `
  <div class="alert alert-info">
  <h1> {{title}} </h1>
  </div>
   <router-outlet>

  `,
  providers: [ReactionsService, DrugsService]
})
export class AppComponent {
  title:string = 'OpenFDA drug reaction lookup system';
}
