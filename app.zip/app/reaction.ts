export class Reaction {
    //foundReactionmeddrapt: string;
    constructor(public foundReactionmeddrapt: string) { }
}
