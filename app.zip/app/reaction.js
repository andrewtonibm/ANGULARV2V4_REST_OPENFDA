"use strict";
var Reaction = (function () {
    //foundReactionmeddrapt: string;
    function Reaction(foundReactionmeddrapt) {
        this.foundReactionmeddrapt = foundReactionmeddrapt;
    }
    return Reaction;
}());
exports.Reaction = Reaction;
//# sourceMappingURL=reaction.js.map