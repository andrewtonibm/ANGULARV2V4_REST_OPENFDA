"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var reaction_1 = require('./reaction');
var reactions_service_1 = require('./reactions.service');
var drugs_service_1 = require('./drugs.service');
//##############################################################
var ReactionsListComponent = (function () {
    //##############################################################
    function ReactionsListComponent(reactionsService, drugsService, route, router) {
        this.reactionsService = reactionsService;
        this.drugsService = drugsService;
        this.route = route;
        this.router = router;
        this.selectedReaction = new reaction_1.Reaction("Please select");
        this.reactions = [];
        this.errorMessage = '';
        this.isLoading = true;
        this.show = false;
        this.drugs = [];
    }
    ReactionsListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.reactionsService
            .getAllReactions()
            .subscribe(
        /* happy path */ function (p) { return _this.reactions = p; }, 
        /* error path */ function (e) { return _this.errorMessage = e; }, 
        /* onComplete */ function () { return _this.isLoading = false; });
    };
    //##############################################################
    ReactionsListComponent.prototype.gotoDrugsList = function (reactionInput) {
        var _this = this;
        this.drugsService
            .getAllDrugs(reactionInput)
            .subscribe(function (p) { return _this.drugs = p; }, function (e) { return _this.errorMessage = e; }, function () { return _this.isLoading = false; });
        this.router.navigate(['/reactions']);
    };
    ReactionsListComponent = __decorate([
        core_1.Component({
            selector: 'reactions-list',
            template: "\n\n\n\n\n\n\n\n  <section>\n      <section *ngIf=\"errorMessage\">\n      <div class=\"alert alert-warning\">\n        {{errorMessage}}\n      </div>\n  </section>\n      \n\n    \n   <section>   \n<div class=\"row\">\n\n\t\t<select [(ngModel)]=\"selectedReaction.foundReactionmeddrapt\">\n  \t\t\t<option *ngFor=\"let temp of reactions\" value= {{temp.foundReactionmeddrapt}}>\n     \t\t\t{{temp.foundReactionmeddrapt}}\n  \t\t\t</option>\n\t\t</select>\n</div>\n\n<div class=\"row\">\n\n\n\t\n  \t<label for=\"ex3\">&nbsp;</label>\n      \t<button class=\"btn btn-primary form-control\"\n      \t(click)=\"gotoDrugsList(selectedReaction.foundReactionmeddrapt)\">Find Drugs</button>\n\n</div>\n   </section>\n   \n   \n   \n   <section> \n\n<div class=\"container container-fluid\">\n  <h2>Drugs found with selected reaction {{selectedReaction.foundReactionmeddrapt}}</h2>\n  <h3>Ordered by relevant count</h3>\n         \n  <table class=\"table table-striped  table-bordered table-hover table-responsive\">\n    <thead>\n      <tr>\n        <th>Relevant Count</th>\n        <th>Generic Name</th>\n\t<!--<th>Brand Name</th>-->\n        <th>Reaction 1</th>\n        <th>Reaction 2</th>\n        <th>Reaction 3</th>\n      </tr>\n    </thead>\n    <tbody>\n\t<tr *ngFor=\"let drug of drugs\">\n          <td>{{drug.relevantCount}}</td>\n          <td>{{drug.foundGenericName}}</td>\n         <!-- <td>{{drug.foundBrand_name}}</td>-->\n\t  <td>{{drug.foundReaction0}}</td> \n\t  <td>{{drug.foundReaction1}}</td> \n\t  <td>{{drug.foundReaction2}}</td>\n        </tr>\n    </tbody>\n  </table>\n</div>\n\n    <div class=\"col-sm-4\" style=\"background-color:white;\">\n      <p>\n \t <img class=\"img-responsive\" src=\"./PIlls-Stacked.jpg\" width=\"460\" height=\"345\">       \n      </p>\n    </div>\n\n\n\n\n\n \n \n\n</section>\n\n      \n      \n\n      <section *ngIf=\"errorMessage\">\n        {{errorMessage}}\n      </section>\n\n\n\n  "
        }), 
        __metadata('design:paramtypes', [reactions_service_1.ReactionsService, drugs_service_1.DrugsService, router_1.ActivatedRoute, router_1.Router])
    ], ReactionsListComponent);
    return ReactionsListComponent;
}());
exports.ReactionsListComponent = ReactionsListComponent;
//# sourceMappingURL=reactions-list.component.js.map