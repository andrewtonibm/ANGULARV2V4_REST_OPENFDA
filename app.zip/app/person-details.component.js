"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var drug_service_1 = require('./drug.service');
var DrugsListComponent = (function () {
    function DrugsListComponent(drugsService) {
        this.drugsService = drugsService;
        this.drug = [];
        this.errorMessage = '';
        this.isLoading = true;
    }
    DrugsListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.drugsService
            .getAll()
            .subscribe(
        /* happy path */ function (p) { return _this.drugs = p; }, 
        /* error path */ function (e) { return _this.errorMessage = e; }, 
        /* onComplete */ function () { return _this.isLoading = false; });
    };
    DrugsListComponent = __decorate([
        core_1.Component({
            selector: 'drugs-list',
            template: "\n  <section>\n    <section *ngIf=\"isLoading && !errorMessage\">\n    Loading our hyperdrives!!! Retrieving data...\n    </section>\n      <ul>\n        <!-- this is the new syntax for ng-repeat -->\n        <li *ngFor=\"let drug of drugs\">\n          {{drug.name}}\n          </a>\n        </li>\n      </ul>\n      <section *ngIf=\"errorMessage\">\n        {{errorMessage}}\n      </section>\n  </section>\n  \n  <section>\n      <button (click)=\"gotoPeoplesList()\">Find Drugs with this Reaction</button>\n  </section>\n  "
        }), 
        __metadata('design:paramtypes', [(typeof (_a = typeof drug_service_1.DrugsService !== 'undefined' && drug_service_1.DrugsService) === 'function' && _a) || Object])
    ], DrugsListComponent);
    return DrugsListComponent;
    var _a;
}());
exports.DrugsListComponent = DrugsListComponent;
//# sourceMappingURL=person-details.component.js.map