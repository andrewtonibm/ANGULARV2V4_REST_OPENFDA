"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var drugs_service_1 = require('./drugs.service');
/***************************************
*
*
***************************************/
var DrugsListComponent = (function () {
    function DrugsListComponent(drugsService, route, router) {
        this.drugsService = drugsService;
        this.route = route;
        this.router = router;
        this.drugs = [];
        this.errorMessage = '';
        this.isLoading = true;
    }
    DrugsListComponent.prototype.ngOnInit = function () {
    };
    //##############################################################
    DrugsListComponent.prototype.gotoSelectReactionList = function () {
        //let link = ['/drugs/'+reactionDrugCountInput+'/'+reactionInput];
        this.router.navigate(['/reactions/']);
    };
    DrugsListComponent = __decorate([
        core_1.Component({
            selector: 'drugs-list',
            template: "\n\n  \n  <section *ngIf=\"errorMessage\">\n      <div class=\"alert alert-warning\">\n        {{errorMessage}}\n      </div>\n  </section>\n      \n    <section *ngIf=\"isLoading && !errorMessage\">\n          <div class=\"alert alert-warning\">\n  \t\t  Loading our hyperdrives!!! Retrieving data...\n          </div>\n    </section>\n\n<section>\n\n  <section>\n      <button class=\"btn btn-primary\" (click)=\"gotoSelectReactionList()\">Select another REACTION</button>\n  </section> \n\n\n<div class=\"container\">\n  <h2>Drugs found with selected reaction</h2>\n  <h3>Ordered by relevant count</h3>\n         \n  <table class=\"table table-striped  table-bordered table-hover table-responsive\">\n    <thead>\n      <tr>\n        <th>Relevant Count</th>\n        <th>Generic Name</th>\n\t<th>Brand Name</th>\n        <th>Reaction 1</th>\n        <th>Reaction 2</th>\n        <th>Reaction 3</th>\n      </tr>\n    </thead>\n    <tbody>\n\t<tr *ngFor=\"let drug of drugs\">\n          <td>{{drug.relevantCount}}</td>\n          <td>{{drug.foundGenericName}}</td>\n          <td>{{drug.foundBrand_name}}</td>\n\t  <td>{{drug.foundReaction0}}</td> \n\t  <td>{{drug.foundReaction1}}</td> \n\t  <td>{{drug.foundReaction2}}</td>\n        </tr>\n    </tbody>\n  </table>\n</div>\n</section>\n\n\n  \n  <section>\n      <button class=\"btn btn-primary\" (click)=\"gotoSelectReactionList()\">Select another REACTION</button>\n  </section>\n  "
        }), 
        __metadata('design:paramtypes', [drugs_service_1.DrugsService, router_1.ActivatedRoute, router_1.Router])
    ], DrugsListComponent);
    return DrugsListComponent;
}());
exports.DrugsListComponent = DrugsListComponent;
//# sourceMappingURL=drugs-list.component.js.map