import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Response } from '@angular/http';


import { Reaction } from './reaction';
import { ReactionsService } from './reactions.service';
import { Drug } from './drug';
import { DrugsService } from './drugs.service';


//##############################################################
@Component({
  selector: 'reactions-list',
  template: `







  <section>
      <section *ngIf="errorMessage">
      <div class="alert alert-warning">
        {{errorMessage}}
      </div>
  </section>
      

    
   <section>   
<div class="row">

		<select [(ngModel)]="selectedReaction.foundReactionmeddrapt">
  			<option *ngFor="let temp of reactions" value= {{temp.foundReactionmeddrapt}}>
     			{{temp.foundReactionmeddrapt}}
  			</option>
		</select>
</div>

<div class="row">


	
  	<label for="ex3">&nbsp;</label>
      	<button class="btn btn-primary form-control"
      	(click)="gotoDrugsList(selectedReaction.foundReactionmeddrapt)">Find Drugs</button>

</div>
   </section>
   
   
   
   <section> 

<div class="container container-fluid">
  <h2>Drugs found with selected reaction {{selectedReaction.foundReactionmeddrapt}}</h2>
  <h3>Ordered by relevant count</h3>
         
  <table class="table table-striped  table-bordered table-hover table-responsive">
    <thead>
      <tr>
        <th>Relevant Count</th>
        <th>Generic Name</th>
	<!--<th>Brand Name</th>-->
        <th>Reaction 1</th>
        <th>Reaction 2</th>
        <th>Reaction 3</th>
      </tr>
    </thead>
    <tbody>
	<tr *ngFor="let drug of drugs">
          <td>{{drug.relevantCount}}</td>
          <td>{{drug.foundGenericName}}</td>
         <!-- <td>{{drug.foundBrand_name}}</td>-->
	  <td>{{drug.foundReaction0}}</td> 
	  <td>{{drug.foundReaction1}}</td> 
	  <td>{{drug.foundReaction2}}</td>
        </tr>
    </tbody>
  </table>
</div>

    <div class="col-sm-4" style="background-color:white;">
      <p>
 	 <img class="img-responsive" src="./PIlls-Stacked.jpg" width="460" height="345">       
      </p>
    </div>





 
 

</section>

      
      

      <section *ngIf="errorMessage">
        {{errorMessage}}
      </section>



  `
})

//##############################################################
export class ReactionsListComponent implements OnInit {


  selectedReaction: Reaction=new Reaction("Please select");

  reactions: Reaction[] = [];
  errorMessage: string = '';
  isLoading: boolean = true;
  sub: any;
  private show = false;

  
  drugs: Drug[] = [];

    //##############################################################
    constructor(private reactionsService: ReactionsService,
    		private drugsService: DrugsService,
                private route: ActivatedRoute,
                private router: Router){
    }

  ngOnInit(){
  
  
    this.reactionsService
      .getAllReactions()
      .subscribe(
         /* happy path */ p => this.reactions = p,
         /* error path */ e => this.errorMessage = e,
         /* onComplete */ () => this.isLoading = false);
	 
  }



  //##############################################################
  gotoDrugsList(reactionInput:string){

   	this.drugsService
	    .getAllDrugs(reactionInput)
	    .subscribe(p => this.drugs = p, 
	           e => this.errorMessage = e,
		   () => this.isLoading = false);


	this.router.navigate(['/reactions');
  }
}
