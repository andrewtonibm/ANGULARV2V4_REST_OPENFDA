"use strict";
var router_1 = require('@angular/router');
var reactions_list_component_1 = require('./reactions-list.component');
// Route config let's you map routes to components
var routes = [
    //############################# map '/reactions' to the reactions list component
    //andrewton DONE CODE
    {
        path: 'reactions',
        component: reactions_list_component_1.ReactionsListComponent,
    },
];
exports.routing = router_1.RouterModule.forRoot(routes);
//# sourceMappingURL=app.routes.js.map